# README

Simply run 'rails s' to start this backend server